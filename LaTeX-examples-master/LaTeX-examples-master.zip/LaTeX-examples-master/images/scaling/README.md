Compiled example
----------------
![Example](scaling.png)
