The [`subfig`](http://www.ctan.org/pkg/subfig) package is the way to go
when you want to use multiple images side by side.