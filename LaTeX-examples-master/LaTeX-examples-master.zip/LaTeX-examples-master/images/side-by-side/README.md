Compiled example
----------------
![Example](side-by-side.png)
