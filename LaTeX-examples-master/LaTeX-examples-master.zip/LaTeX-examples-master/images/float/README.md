Compiled example
----------------
![Example](float.png)
