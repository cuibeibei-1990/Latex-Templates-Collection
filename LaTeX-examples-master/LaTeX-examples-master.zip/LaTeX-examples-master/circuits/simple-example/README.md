Compiled example
----------------
![Example](simple-example.png)
