Compiled example
----------------
![Example](d-latch-with-nand.png)
