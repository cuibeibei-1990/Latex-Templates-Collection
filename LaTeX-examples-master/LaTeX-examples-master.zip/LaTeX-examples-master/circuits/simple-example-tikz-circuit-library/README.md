Compiled example
----------------
![Example](simple-example-tikz-circuit-library.png)
