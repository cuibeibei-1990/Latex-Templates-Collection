Compiled example
----------------
![Example](topology-r-spiral-covering-s.png)

Credits
-------

This graph was created by [Alex](http://tex.stackexchange.com/users/22467/alex) ([source](http://tex.stackexchange.com/a/149706/5645))
