About
-----
This is a 20 minutes presentation for my bachelors thesis. It is the final
presentation.

It will be at Thursday, the 6. November 2014 at 11:45 in [building 50.20](http://www.kithub.de/map/2210)
(ehemalige Kinderklinik) in the conference room (institue of Prof. Waibel; I think it's the 3rd floor).


KIT-Style
---------
This one doesn't compile, as you need the KIT-Style (logos, layout,
color theme)

Please take a look at the presentation "Tutorenschulung" for further
information.
