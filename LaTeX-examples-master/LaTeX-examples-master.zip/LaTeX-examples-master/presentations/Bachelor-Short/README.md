About
-----
This is a 20 minutes presentation for my bachelors thesis. At this point,
I still have one (of four) months left. So work is still in progress.

KIT-Style
---------
This one doesn't compile, as you need the KIT-Style (logos, layout,
color theme)

Please take a look at the presentation "Tutorenschulung" for further
information.
