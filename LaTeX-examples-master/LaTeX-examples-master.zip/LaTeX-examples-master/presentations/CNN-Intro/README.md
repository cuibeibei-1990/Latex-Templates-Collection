# CNNs: Theory and Application

[PDF download](CNN-Intro.pdf)
