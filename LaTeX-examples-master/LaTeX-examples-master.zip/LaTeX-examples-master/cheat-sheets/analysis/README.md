Compiled example
----------------
![Example](Analysis_Wichtige_Formeln.png)
