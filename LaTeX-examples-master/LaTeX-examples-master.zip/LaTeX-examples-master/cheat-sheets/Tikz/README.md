I took this from a [StackExchange Question](http://tex.stackexchange.com/a/84757/5645)

If you want to change it (I know you can make it better with LaTeX!)
or if you have some important commant, feel free to submit a merge
request or send me an e-mail (info@martin-thoma.de)


It would be great, if we could make the most important commands on one page.
