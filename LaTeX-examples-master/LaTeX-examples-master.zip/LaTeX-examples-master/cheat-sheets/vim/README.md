I took http://stdout.org/~winston/latex/ as a template.
