Compiled example
----------------
![Example](strange-signs.png)
