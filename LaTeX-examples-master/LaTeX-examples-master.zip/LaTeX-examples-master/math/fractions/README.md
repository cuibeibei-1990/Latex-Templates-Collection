Compiled example
----------------
![Example](fractions.png)
