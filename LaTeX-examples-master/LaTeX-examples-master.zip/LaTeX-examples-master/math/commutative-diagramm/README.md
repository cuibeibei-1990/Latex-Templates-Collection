Compiled example
----------------
![Example](commutative-diagramm.png)
