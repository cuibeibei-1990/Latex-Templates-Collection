You might have to run

`sudo apt-get install gnuplot`

first.

For more information about GnuPlot, read [the manual](http://www.gnuplot.info/documentation.html)
