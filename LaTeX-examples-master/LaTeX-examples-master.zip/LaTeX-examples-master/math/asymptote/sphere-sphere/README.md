THIS DOES NOT WORK RIGHT NOW!

Compiled example
----------------
![Example](sphere-sphere.png)

Credits
-------
Thanks to [g.kov](http://tex.stackexchange.com/users/27243/g-kov) ([answer](http://tex.stackexchange.com/a/121900/5645))
