Compiled example
----------------
![Example](sizes.png)
