You might also be interested in

* documents/mathe-vorlage
* documents/Analysis I - III
* tikz
  * 3d-functions
  * intersecting-lines-1
  * isosceles-triangle
  * many more
