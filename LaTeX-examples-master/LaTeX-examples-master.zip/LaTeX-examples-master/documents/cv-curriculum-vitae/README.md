This is from
http://www.latextemplates.com/template/two-column-one-page-cv

You can get the font from here:
http://www.911fonts.com/font-download/download_ZapfinoLinotypeOneRegular_11392.htm

You need Times New Roman:

```bash
sudo apt-get install msttcorefonts
```