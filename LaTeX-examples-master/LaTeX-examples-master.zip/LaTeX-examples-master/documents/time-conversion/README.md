Compiled example
----------------
![Example](time-conversion.png)
