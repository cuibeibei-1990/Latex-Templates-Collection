[Download PDF](https://github.com/MartinThoma/LaTeX-examples/raw/master/documents/normal-distribution/normal-distribution.pdf)

Compiled example
----------------
![Example](normal-distribution.png)

## Credits

Thanks to [Jake](http://tex.stackexchange.com/users/2552/jake) for the
plot of the normal distribution ([link](http://tex.stackexchange.com/a/100030/5645))