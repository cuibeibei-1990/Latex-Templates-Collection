Compiled example
----------------
![Example](testpage-star.png)
