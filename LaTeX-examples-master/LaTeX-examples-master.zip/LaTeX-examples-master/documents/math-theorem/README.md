See [Theorem environment with hanging indentation](http://tex.stackexchange.com/a/151586/5645)
