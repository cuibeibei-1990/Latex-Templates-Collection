Compiled example
----------------
![Example](chess-chessboard-shortest-game.png)
