Compiled example
----------------
![Example](chess-skak-simple-example.png)
