* Zu [Web Engineering](http://martin-thoma.com/web-engineering/)
* Die `FS-Eule.pdf` müsst ihr noch von [hier](http://www.fsmi.uni-karlsruhe.de/Studium/Pruefungsprotokolle/) holen.
