Example for a contract - in German - about giving your apartment to somebody
else for a short time.