* Zu [Analysetechniken großer Datenbestände](https://martin-thoma.com/analysetechniken-grosser-datenbestaende)
* Die `FS-Eule.pdf` müsst ihr noch von [hier](http://www.fsmi.uni-karlsruhe.de/Studium/Pruefungsprotokolle/) holen.
