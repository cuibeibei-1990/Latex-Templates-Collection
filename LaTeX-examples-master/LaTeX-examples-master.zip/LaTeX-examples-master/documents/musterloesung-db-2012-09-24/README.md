Auf Basis von [Nilans und Stefans pastebin](http://pastebin.com/JfDfrVMV) entstanden.
