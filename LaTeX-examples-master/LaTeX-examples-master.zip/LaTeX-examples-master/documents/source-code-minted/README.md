Credits
=======
Thanks to [cyberSingularity](http://tex.stackexchange.com/users/17427/cybersingularity)
for [his help](http://tex.stackexchange.com/a/83218/5645).
