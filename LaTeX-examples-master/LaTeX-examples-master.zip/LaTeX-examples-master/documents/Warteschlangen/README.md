Das hier angebotene Skript wurde von Karl Grill erstellt.
Das original ist [hier](http://www.ci.tuwien.ac.at/~grill/) zu finden. Die hier
angebotene Version wurde (in Kleinigkeiten) von Martin Thoma überarbeitet.