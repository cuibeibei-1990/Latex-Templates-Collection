Prelude> head []
*** Exception: Prelude.head: empty list
Prelude> tail []
*** Exception: Prelude.tail: empty list
Prelude> tail [1]
[]
Prelude> head [1]
1
Prelude> null []
True
Prelude> null [[]]
False
