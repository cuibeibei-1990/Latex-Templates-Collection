f x = x * x
g x = x - 1
h = (f . g)
i = (g . f)