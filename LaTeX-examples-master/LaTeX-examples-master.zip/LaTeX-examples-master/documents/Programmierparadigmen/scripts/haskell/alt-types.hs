type Prename = String
type Age = Double
type Person = (Prename, Age)
type Friends = [Person]
type Polynom = [Double]