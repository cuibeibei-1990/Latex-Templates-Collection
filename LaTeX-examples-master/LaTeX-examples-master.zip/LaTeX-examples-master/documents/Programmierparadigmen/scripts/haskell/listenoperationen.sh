Prelude> let mylist = [1,2,3,4,5,6]
Prelude> head mylist
1
Prelude> tail mylist
[2,3,4,5,6]
Prelude> take 3 mylist
[1,2,3]
Prelude> drop 2 mylist
[3,4,5,6]
Prelude> mylist
[1,2,3,4,5,6]
Prelude> mylist ++ sndList
[1,2,3,4,5,6,9,8,7]
