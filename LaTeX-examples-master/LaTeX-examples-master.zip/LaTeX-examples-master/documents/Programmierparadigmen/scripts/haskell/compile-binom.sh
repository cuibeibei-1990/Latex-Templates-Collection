$ ghci binomialkoeffizient.hs 
GHCi, version 7.4.2: 
    http://www.haskell.org/ghc/  
    :? for help
Loading package ghc-prim ... linking ... done.
Loading package integer-gmp ... linking ... done.
Loading package base ... linking ... done.
[1 of 1] Compiling Main             
        ( binomialkoeffizient.hs, interpreted )
Ok, modules loaded: Main.
*Main> binom 5 2
10
