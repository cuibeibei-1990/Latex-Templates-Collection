putStrLn (show $ 1 - 2)
putStrLn $ show (1 - 2)
putStrLn $ show $ 1 - 2