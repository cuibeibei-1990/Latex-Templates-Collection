fib = 0 : 1 : zipWith (+) fibs (tail fibs)
