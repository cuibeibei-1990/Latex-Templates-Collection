>>> let f = 3; g = f where f = 7
>>> f
3
>>> g
7