ArrayList<String>  l1 = new ArrayList<String>();
ArrayList<Integer> l2 = new ArrayList<Integer>();
