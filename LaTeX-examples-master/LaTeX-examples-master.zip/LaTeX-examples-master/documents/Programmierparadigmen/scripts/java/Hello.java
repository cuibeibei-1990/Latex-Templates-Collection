public class Hello {
    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
}