class Person (
    val firstName: String,
    var lastName: String,
    age: Int) {
    println("This is the constructur.")

    def sayHi() = println("Hello world!")
}