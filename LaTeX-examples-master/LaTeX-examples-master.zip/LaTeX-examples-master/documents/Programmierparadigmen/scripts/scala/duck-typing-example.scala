def quacker(duck: 
    {def quack(value: String): String}) {
  println (duck.quack("like a duck!"))
}