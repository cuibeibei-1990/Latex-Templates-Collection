for(a <- 1 until 10){
    println("Value of a: " + a );
}