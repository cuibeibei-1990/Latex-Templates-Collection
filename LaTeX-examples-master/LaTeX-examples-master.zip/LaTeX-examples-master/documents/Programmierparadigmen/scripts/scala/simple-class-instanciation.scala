val anna = new Person("anna", "bern", 18)
anna.sayHi()