$ scala
Welcome to Scala version 2.9.2 [...]

scala> println("Hello world")
Hello world