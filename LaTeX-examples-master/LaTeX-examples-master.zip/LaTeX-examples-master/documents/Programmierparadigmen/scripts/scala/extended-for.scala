val list = List("USA", "Russia", "Germany")
for(country <- list)
    println(country)