farbe(blau).
farbe(gelb).
farbe(gruen).
farbe(rot).