#!/usr/bin/swipl -q -t main -f

main :- writeln('Hello world!').