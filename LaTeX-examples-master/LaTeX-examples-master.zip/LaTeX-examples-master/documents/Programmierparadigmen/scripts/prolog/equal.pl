?- X = Y.
X = Y.

?- X == Y.
false.