$ swipl -c human.pro 
% library(swi_hooks) compiled into pce_swi_hooks 
%                0.00 sec, 2,224 bytes
% human.pro compiled 0.00 sec, 644 bytes
% /usr/lib/swi-prolog/library/listing compiled into 
%                prolog_listing 0.00 sec, 21,648 bytes
