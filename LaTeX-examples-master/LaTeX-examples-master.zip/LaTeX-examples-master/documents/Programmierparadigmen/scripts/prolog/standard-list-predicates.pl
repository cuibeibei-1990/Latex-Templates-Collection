sort(+List, -Sorted)
msort(+List, -Sorted)
memberchk(?Elem, +List)