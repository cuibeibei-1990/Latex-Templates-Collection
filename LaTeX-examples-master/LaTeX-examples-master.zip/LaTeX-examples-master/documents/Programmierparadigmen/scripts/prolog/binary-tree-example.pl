T0 = t(a, nil, nil).
T1 = t(a, t(b, nil), t(c, nil)).
T2 = t(a, t(b, t(c, nil, nil), 
               t(d, nil, nil)
          ), 
          t(e, nil, nil)
      ).
T3 = nil