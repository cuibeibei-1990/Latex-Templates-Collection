?- X is 3^2.
X = 9.

?- Y is X*X.
ERROR: is/2: Arguments are not sufficiently 
instantiated

?- X is X+1.
ERROR: is/2: Arguments are not sufficiently 
instantiated