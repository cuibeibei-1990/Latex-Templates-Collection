Dies ist ein **inoffizielles, von Studenten erstelltes Skript**
zur Vorlesung "Programmierparadigmen" am KIT bei
Herrn Prof. Dr. Snelting (WS 2013/2014).

Docker
------
You might also be interested in the [programming paradigms docker project](https://github.com/kitedu/programming-paradigms).