Nur mal aus Interesse versuche ich zu verfolgen, wie viel Zeit
in dem Erstellen dieses Skripts steckt:

|Datum      | Uhrzeit       | Autor | Bemerkung
|-----------|---------------|----------------------------------------
|01.02.2014 | 13:30 - 13:45 | Thoma | Initialisierung; Grobe Struktur
|01.02.2014 | 14:00 - 14:45 | Thoma | ASCII-Tabelle in C angefangen; Kapitel "Programmiersprachen" hinzugefügt; erste Definitionen
|01.02.2014 | 14:45 - 15:30 | Thoma | Haskell angefangen
|01.02.2014 | 11:15 - 11:45 | Thoma | Haskell Class Hierachy
|01.02.2014 | 16:00 - 17:00 | Thoma | Abschnitt über Rekursion hinzugefügt
|04.02.2014 | 13:00 - 14:00 | Thoma | Viel zu Haskell ergänzt; Funktionen höherer Ordnung beschrieben
|14.02.2014 | 08:30 - 09:30 | Thoma | Abschnitt über Compilerbau begonnen
|20.02.2014 | 09:30 - 10:42 | Thoma | Abschnitt über Reguläre Ausdrücke und Lex hinzugefügt