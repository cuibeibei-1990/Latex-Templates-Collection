## Vorbereitung

1. Erklären worum es geht
2. Fragen, ob schon mal mathematische Formeln zur Textsetzung in den
   Computer eingegeben wurden. Falls ja, weiter mit der Umfrage. Sonst nicht.