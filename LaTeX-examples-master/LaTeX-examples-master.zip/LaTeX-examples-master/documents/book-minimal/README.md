Source: http://www.reddit.com/r/nosleep/comments/2dh3gj/the_afterlife_experiment/

Author: [The_Dalek_Emperor](http://www.reddit.com/user/The_Dalek_Emperor)

## Credits

* [How can I create documents in LaTeX using a calligraphic first letter for chapters?](http://tex.stackexchange.com/q/769/5645)



## Used regexes

### Regex: Quotes

* Search: `"(.*?)"`, `"(.*?)”`, `“(.*?)"`
* Replace: `\\enquote{$1}`

### dots

* Search: `...`, `…`
* Replace: `\dots`