Credits
-------
Dieses Skript stammt usprünglich von http://mitschriebwiki.nomeata.de/
("Analysis II - Bachelorversion" bei Dr. C. Schmoeger vom Sommersemester 2010)
