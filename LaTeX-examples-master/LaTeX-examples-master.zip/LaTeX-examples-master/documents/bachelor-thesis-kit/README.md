Source code of my bachelors thesis. See
[martin-thoma.com/write-math](http://martin-thoma.com/write-math/)
for more information.