Compiled example
----------------
![Example](math-sylvester-diagonal-matrix.png)
