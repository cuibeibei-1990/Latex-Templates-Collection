Compiled example
----------------
![Example](printer-testpage.png)
