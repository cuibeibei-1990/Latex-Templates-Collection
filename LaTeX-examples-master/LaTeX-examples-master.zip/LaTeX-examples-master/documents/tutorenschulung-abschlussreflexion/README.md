You have to add
* logos/KITLogo_RGB.pdf

You should change
* your signature
* your personal information
