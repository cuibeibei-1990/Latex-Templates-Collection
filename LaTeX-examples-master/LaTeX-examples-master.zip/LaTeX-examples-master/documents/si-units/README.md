Read the [manual](ftp://ftp.tex.ac.uk/tex-archive/macros/latex/exptl/siunitx/siunitx.pdf)
for more information how `siunitx` works.

Material
--------
* [Why use a package to typeset units?](http://tex.stackexchange.com/q/107818/5645)
