* Zu [Neuronale Netze](https://martin-thoma.com/neuronale-netze-vorlesung)
* Die `FS-Eule.pdf` müsst ihr noch von [hier](http://www.fsmi.uni-karlsruhe.de/Studium/Pruefungsprotokolle/) holen.
