public class Jungle {
    public static void main(String[] args) {
        Animal felix = new Cat();
        System.out.println(felix.getCatSound());
        System.out.println(felix.getSound());
    }
}
