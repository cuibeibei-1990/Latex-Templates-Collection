Credits
=======
Thanks to Martin Scharrer, whose [solution](http://tex.stackexchange.com/a/30310/5645)
I have used to create this minimal example.
