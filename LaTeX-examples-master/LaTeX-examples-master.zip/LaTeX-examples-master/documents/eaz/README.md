Compiled example
----------------
![Example](eaz.png)
