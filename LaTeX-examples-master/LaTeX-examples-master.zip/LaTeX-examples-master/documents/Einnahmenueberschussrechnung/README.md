* Einmalig müssen Parameter in der `myInformation.tex` bearbeitet werden.
* Dann nur noch jedes Jahr die vier `.csv`-Dateien und gegebenenfalls
  unter `Einnahmenueberschussrechnung.tex` Anmerkungen machen

Tags: Steuer, Steuererklärung, LaTeX, Finanzen, EÜR
