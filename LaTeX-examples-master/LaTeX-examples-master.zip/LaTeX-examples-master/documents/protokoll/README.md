Dieses LaTeX-Dokument soll als Vorlage für Protokolle dienen.
Falls es Verbesserungsvorschläge oder Wünsche (z.B. weitere
Shortcuts) gibt, bitte an info@martin-thoma.de

Shortcuts
---------
<table>
  <tr>
    <th>Shortcut</th>
    <th>erzeugt</th>
  </tr>
  <tr>
    <td>\arrow</td>
    <td>&rarr;</td>
  </tr>
  <tr>
    <td>\implies</td>
    <td>&rArr;</td>
  </tr>
</table>

Weiteres
--------
* [CTAN Protocol](http://www.ctan.org/pkg/protocol) (wird momentan nicht benutzt)
