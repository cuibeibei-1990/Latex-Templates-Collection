Compiled example
----------------
![Example](chess-chessboard-simple-example.png)
