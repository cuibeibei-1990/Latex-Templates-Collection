Compiled example
----------------
![Example](csv-physik.png)


Notes
-----

You may not have a sharp `#` within your csv file!