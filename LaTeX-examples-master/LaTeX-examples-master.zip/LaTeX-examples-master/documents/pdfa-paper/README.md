Minimal example for a PDF/A paper:

http://www.pdf-tools.com/pdf/validate-pdfa-online.aspx

```text
Validating file "pdfa-paper.pdf" for conformance level pdfa-1b
  Missing attribute id in XMP packet header.
The document does not conform to the requested standard.
The document's meta data is either missing or inconsistent or corrupt.
Done.
```