* Zu [ML1](https://martin-thoma.com/machine-learning-1-course/)
  und [ML2](https://martin-thoma.com/machine-learning-2-course/)