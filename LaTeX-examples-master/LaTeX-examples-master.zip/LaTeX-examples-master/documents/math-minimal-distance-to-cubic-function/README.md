This paper is currently (09.01.2014) written. Statements might be
incorrect, strucutre and content will change.

The rendered version is called `math-minimal-distance-to-cubic-function.pdf`.
