[Download compiled PDF](https://github.com/MartinThoma/write-math-paper/blob/master/write-math-ba-paper.pdf?raw=true)

## License

This is work is licensed under [CC BY-NC-ND 3.0](https://creativecommons.org/licenses/by-nc-nd/3.0/).

## Spell checking
* Spell checking `for f in ch*.tex; do aspell --lang=en --mode=tex check $f; done`
* Spell checking `for f in ch*.tex; do /home/moose/GitHub/Academic-Writing-Check/checkwriting $f; done`
* Spell checking with `http://www.reverso.net/spell-checker`
* https://github.com/devd/Academic-Writing-Check
