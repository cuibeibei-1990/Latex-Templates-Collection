Example was created by matth on [tex.stackexchange.com](http://tex.stackexchange.com/a/34136/5645).

A big example .bib-file is [online](http://sunsite.informatik.rwth-aachen.de/ftp/pub/mirror/ctan/macros/latex/contrib/biblatex/doc/examples/biblatex-examples.bib).

A good overview how you can use citations in your LaTeX document is [here](http://merkel.zoneo.net/Latex/natbib.php).

[literatur-generator.de](http://www.literatur-generator.de/) helps you to generate bibtex entries.
