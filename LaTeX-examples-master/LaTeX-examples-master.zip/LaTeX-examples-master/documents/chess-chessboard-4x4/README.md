Compiled example
----------------
![Example](chess-chessboard-4x4.png)
