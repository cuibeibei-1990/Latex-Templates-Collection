I had the idea to create a math dictionary for German <-> English.

More about this on StackExchange: [Is there an environment / document class for dictionaries?](http://tex.stackexchange.com/q/149754/5645)
