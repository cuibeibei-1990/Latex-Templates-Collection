Compiled example
----------------
![Example](csv-line-plot.png)
