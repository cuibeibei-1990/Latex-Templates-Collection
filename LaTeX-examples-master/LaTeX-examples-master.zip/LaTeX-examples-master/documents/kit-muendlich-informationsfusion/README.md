* Zu [Informationsfusion](https://martin-thoma.com/informationsfusion/)
* Die `FS-Eule.pdf` müsst ihr noch von [hier](http://www.fsmi.uni-karlsruhe.de/Studium/Pruefungsprotokolle/) holen.
