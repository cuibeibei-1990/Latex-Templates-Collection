Found on http://www.martin-kumm.de/tex_gantt_package.php
