This template is for everybody who wants to study mathematics as a minor
subject for the masters degree in computer science at KIT, but who does
not want to study Algebra.

1. First, you should make a plan what you want to study (15-18 ECTS)
2. Go to Dr. Kühnlein and ask him if he is ok with that. He should give
   you a written permission
3. Fill out the template, sign it, add Dr. Kühnleins permission and give it
   to ... hm ... [Dr. Gheta](http://www.informatik.kit.edu/english/2381_5540.php)?