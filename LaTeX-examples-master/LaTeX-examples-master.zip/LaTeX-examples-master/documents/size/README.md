Compiled example
----------------
![Example](size.png)
