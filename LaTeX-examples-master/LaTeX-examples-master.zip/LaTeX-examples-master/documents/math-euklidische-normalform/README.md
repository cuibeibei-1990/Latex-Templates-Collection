Compiled example
----------------
![Example](math-euklidische-normalform.png)
