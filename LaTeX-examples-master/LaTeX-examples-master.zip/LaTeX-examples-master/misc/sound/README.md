Seen on [tex.stackexchange](http://tex.stackexchange.com/q/8918/5645) by
[Yiannis Lazarides](http://tex.stackexchange.com/users/963/yiannis-lazarides).

I could not get it work. The reason is probably that you need Texlive 2014.