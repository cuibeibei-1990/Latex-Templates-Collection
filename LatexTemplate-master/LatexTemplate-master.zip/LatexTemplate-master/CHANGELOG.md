# Version History of this project
Specific Version histories and informations can be found in the specific 'CHANGELOG' textfile within the subdirectory of interes.
Below is a list of the current Subdirectory-Version
* `Homework` has Version `1.2`
* `Booklet` has Version `1.2`
* `Presentation` has Version `1.1`
* `Paper` has Version `1.0`
