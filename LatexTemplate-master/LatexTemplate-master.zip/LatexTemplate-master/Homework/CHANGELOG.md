# Version History of `Homework`

## Version 1.2
 - unsupport non XeTeX / LuaTeX
 + improve rounding of points
 + introduce subfiles
 + clean up commands
 + clean up class

## Version 1.1
 + decimal points support
 + continous integration
 + more math commands
 + basic TikZ integration

## Version 1.0
 + basic template
 + integer points support
 + code listings
 + generic math commands
