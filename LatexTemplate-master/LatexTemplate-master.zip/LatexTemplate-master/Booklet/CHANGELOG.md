# Version History of `Booklet`

## Version 1.2
 + new project structure
 + some commands for category theory
 + better glossaries support
 + update tikzstuff
 + improve examples

## Version 1.1
 + titlepage
 + basic file organisation
 + glossaries
 + basic commands list

## Version 1.0
 + basic template
 + booklet example
 + code listings
 + definitions and theorems
 + bibliography
 + table of contents
 + frontmatter
