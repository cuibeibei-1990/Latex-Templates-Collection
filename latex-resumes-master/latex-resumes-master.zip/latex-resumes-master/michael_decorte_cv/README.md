# Latex CV template of Michael Decorte

#### Author
Michael Decorte  
[usage](http://linux.dsplabs.com.au/resume-writing-example-latex-template-linux-curriculum-vitae-professional-cv-layout-format-text-p54/)

#### Preview
printed pdf preview  

![screenshot](preview.png)