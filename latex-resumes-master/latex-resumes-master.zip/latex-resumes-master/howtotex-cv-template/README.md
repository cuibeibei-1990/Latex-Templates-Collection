# Two latex CV templates from howToTex

#### Author
[howtoTeX.com](http://www.howtotex.com/)

#### Preview
1. Simple plancv preview  
![screenshot](simple-plaincv/preview.png)

2. Designer's CV preview  
![screenshot](designer/preview.png)