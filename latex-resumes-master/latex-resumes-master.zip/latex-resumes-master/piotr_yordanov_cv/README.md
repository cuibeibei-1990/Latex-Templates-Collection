# CV Templates From Piotr Yordanov

#### Author
[Piotr Yordanov](http://piotry.me/)
[Github](https://github.com/tUrG0n)


#### Preview
cv preview  
![screenshot](preview.png)


#### Note
If you meet the following problem when you compile the main.tex with ***latex***.
```
! LaTeX Error: Cannot determine size of graphic in git.png (no BoundingBox).
```

Please try to use ***xelatex*** or ***pdflatex***. Any question please contact the author.