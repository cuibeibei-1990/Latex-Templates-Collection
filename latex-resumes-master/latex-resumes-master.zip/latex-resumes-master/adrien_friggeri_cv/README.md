# Friggeri Latex CV Templates

#### Author
[Adrien Friggeri](https://github.com/afriggeri/cv) 

#### Preview
friggeri cv preview
![screenshot](preview.png)