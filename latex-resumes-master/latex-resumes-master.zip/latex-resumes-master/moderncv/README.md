# Moderncv

#### Author
[Xavier Danaux <xdanaux@gmail.com>](http://www.ctan.org/tex-archive/macros/latex/contrib/moderncv)  

[Home page](http://www.launch­pad.net/mod­erncv)

#### Preview
Moderncv preview
![screenshot](preview.png)