# Constantinos michael CV template

#### Author
[Constantinos Michael](http://www.constantinos.us/blog/2006/04/12/latex-resume-template)  

#### Preview
printed preview  
![screenshot](preview.png)