%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Feel free to use this template for your book project! Read the /README.txt for an introduction. Check out the accompanying book "Better Books with LaTeX" for step-by-step instructions. Template created by Clemens Lode, LODE Publishing (www.lode.de), mail@lode.de, 8/17/2018.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This directory contains all the back matter items that come after the ending of the last chapter.